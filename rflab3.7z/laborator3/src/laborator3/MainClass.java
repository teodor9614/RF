package laborator3;

public class MainClass {

	public static void main(String[] args) {
		double[][] learningSet;
		try {
			learningSet = FileUtils.readLearningSetFromFile("D:\\Student\\laborator3\\in.txt");
			int numberOfPatterns = learningSet.length;
			int numberOfFeatures = learningSet[0].length;
			System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns,
					numberOfFeatures));
			
			for (int i = 1; i <= learningSet.length - 1; i++) 
			{
				DistanceUtils.EuclidianDistance(learningSet[0][0], learningSet[0][1], learningSet[i][0],
						learningSet[i][1]);
			}
			
			
				DistanceUtils.CebisevDistances(learningSet[0], learningSet[1]);
			
			
			

		} catch (USVInputFileCustomException e) {
			System.out.println(e.getMessage());
		} finally {
			System.out.println("Finished learning set operations");
		}
	}

}

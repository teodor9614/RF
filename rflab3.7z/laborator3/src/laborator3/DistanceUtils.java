package laborator3;

public class DistanceUtils {


	protected static void EuclidianDistance(double a, double b, double c, double d) {
		double eucldist;
		eucldist = (a - b) * (a - b) + (c - d) * (c - d);
		eucldist = Math.sqrt(eucldist);

		System.out.println("Distance between points: ");
		System.out.println(eucldist);
	}

	public static void CebisevDistances(double[] x, double[] y) {
		double dist;
		dist= Math.abs(x[0] - y[0]);
		System.out.println("Cebisev distances: ");
		
		for( int i=0;i<=x.length-1;i++)
		{

			
			if(dist < Math.abs(x[i] - y[i]))
			{
				System.out.println(Math.abs(x[i] - y[i]));
			}
			else
			{
				System.out.println(dist);
			}
			
		}
			
		
		
	
	


		
		
	}

}

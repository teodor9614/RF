package lab3;

public class USVInputFileCustomException extends Exception {

    public USVInputFileCustomException(String message) {
        super(message);
    }

}
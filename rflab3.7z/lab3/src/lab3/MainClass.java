package lab3;


public class MainClass {
	
	
	public static void main(String[] args) {
		double[][] learningSet;
		try {
			learningSet = FileUtils.readLearningSetFromFile("in.txt");
			int numberOfPatterns = learningSet.length;
			int numberOfFeatures = learningSet[0].length;

			for(int pattern=1; pattern<numberOfPatterns; pattern++)
			{
				double euclidianDistance=DistanceUtils.calcualateEuclidianDistance(learningSet[0],learningSet[pattern]);
				double cebisevDistance=DistanceUtils.calcualateCebisevDistance(learningSet[0],learningSet[pattern]);
				double manhattanDistance=DistanceUtils.calcualateManhattanDistance(learningSet[0],learningSet[pattern]);
				double mahalanobisDistance=DistanceUtils.calcualateMahalanobisDistance(learningSet[0],learningSet[pattern], numberOfFeatures);
			
			
			
			System.out.println("Euclidian Distance between first pattern and pattern "+ pattern +" is " +euclidianDistance);
			System.out.println("Cebisev Distance between first pattern and pattern "+ pattern +" is " +cebisevDistance);
			System.out.println("Manhattan Distance between first pattern and pattern "+ pattern +" is " +manhattanDistance);
			System.out.println("Mahalanobis Distance between first pattern and pattern "+ pattern +" is " +mahalanobisDistance);

			
			}
			System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns, numberOfFeatures));
		} catch (USVInputFileCustomException e) {
			System.out.println(e.getMessage());
		} finally {
			System.out.println("Finished learning set operations");
		}
	}

}

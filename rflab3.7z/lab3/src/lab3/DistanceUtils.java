package lab3;

public class DistanceUtils {
	
	public static double calcualateEuclidianDistance(double[] pattern1, double[] pattern2)
	{
		double featureEuclidianDistance=0.0;
		
		featureEuclidianDistance=Math.sqrt(Math.pow(pattern1[0]-pattern2[0], 2)+Math.pow(pattern1[1]-pattern2[1], 2));
		
		return featureEuclidianDistance;
	}
	
	public static double calcualateCebisevDistance(double[] pattern1, double[] pattern2)
	{
		double featureCebisevDistance=0.0;
		double max=Math.abs(pattern1[0]-pattern2[0]);
		for(int k=1; k<pattern1.length;k++)
		{
			if(max<Math.abs(pattern1[k]-pattern2[k]))
				{
				featureCebisevDistance=(Math.abs(pattern1[k]-pattern2[k]));			
				}
		}
		return featureCebisevDistance;
	}
	
	public static double calcualateManhattanDistance(double[] pattern1, double[] pattern2)
	{
		double featureManhattanDistance=0.0;
		
		for(int k=0; k<pattern1.length;k++)
		{
			featureManhattanDistance+=Math.abs(pattern1[k]-pattern2[k]);
		}
		
		return featureManhattanDistance;
	}
	
	public static double calcualateMahalanobisDistance(double[] pattern1, double[] pattern2, int n)
	{
		double featureMahalanobisDistance=0.0;
		
		for(int k=0; k<pattern1.length; k++)
		{
			featureMahalanobisDistance+= Math.pow((pattern1[k]-pattern2[k]), n);
		}
		
		return Math.pow(featureMahalanobisDistance, (double)1/n);
	}

}

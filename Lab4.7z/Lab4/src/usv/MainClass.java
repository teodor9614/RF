package usv;

public class MainClass {

	public static void main(String[] args) {
		double[][] learningSet = null;
		try {
			learningSet = FileUtils.readLearningSetFromFile("D:\\in.txt");
			int numberOfPatterns = learningSet.length;
			int numberOfFeatures = learningSet[0].length;
			System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns,
					numberOfFeatures));
			
			DistanceUtils.initmat(learningSet.length);

			for (int i = 0; i < learningSet.length - 1; i++) {
				for (int j = i + 1; j <= learningSet.length - 1; j++)
					DistanceUtils.EuclidianDistance(learningSet[i], learningSet[j], i, j);
			}
			DistanceUtils.showdist();
			double [][] distancematrix = DistanceUtils.retmat();
			
			int searchedPattern = numberOfPatterns-1;
			
			
			
			
		} catch (USVInputFileCustomException e) {
			System.out.println(e.getMessage());
		} finally {
			System.out.println("Finished learning set operations");
		}
		
	}

}

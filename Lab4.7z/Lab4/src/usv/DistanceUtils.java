package usv;

import java.text.DecimalFormat;

public class DistanceUtils {
	static double sum;
	static double[][] distmat;

	protected static void initmat(int i) {
		distmat = new double[i][i];
	}

	protected static void EuclidianDistance(double[] a, double[] b, int i, int j) {
		double eucldist = 0;
		sum = 0;
		// System.out.println(Math.sqrt(distmat.length));
		for (int k = 0; k < a.length; k++) {
			eucldist = (a[k] - b[k]) * (a[k] - b[k]);
			sum = sum + eucldist;
		}
		distmat[i][j] = Math.sqrt(sum);
	}

	protected static void showdist() {

		DecimalFormat df2 = new DecimalFormat(".##");

		System.out.println("Distance between points: ");
		for (int i = 0; i < distmat.length; i++) {
			System.out.println(" ");
			for (int j = 0; j < distmat.length; j++) {
				distmat[j][i] = distmat[i][j];
				if (distmat[i][j] == 0) {
					System.out.print(0 + " ");
				} else {
					System.out.print(df2.format(distmat[i][j]) + " ");
				}

			}
		}

	}
	protected static double[][] retmat()
	{
		
		return distmat;
	}

}

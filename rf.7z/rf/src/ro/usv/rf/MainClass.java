package ro.usv.rf;

public class MainClass {

	public static void main(String[] args) {
		double[][] learningSet = FileUtils.readLearningSetFromFile("D:\\in.txt");
		FileUtils.writeLearningSetToFile("D:\\out.csv", normalizeLearningSet(learningSet));
	}

	private static double[][] normalizeLearningSet(double[][] learningSet) {
		double[][] normalizedLearningSet = new double[learningSet.length][learningSet[0].length];
		int i, j;
		double jmin, jmax;
		// x ij = (x ij -x jmin )/(x jmax -x jmin )
		
		for (i = 0; i < normalizedLearningSet.length; i++) {
			jmin = jmax = normalizedLearningSet[i][0];
			for (j = 0; j < normalizedLearningSet[0].length; j++) {
				if (normalizedLearningSet[i][j] < jmin) {
					jmin = normalizedLearningSet[i][j];
				} else {
				}
				if (normalizedLearningSet[i][j] > jmax) {
					jmax = normalizedLearningSet[i][j];
				} else {
				}
			}
			normalizedLearningSet[i][j] = (normalizedLearningSet[i][j] - jmin) / (jmax - jmin);
		}

		// .. enter your code here
		return normalizedLearningSet;
	}

}

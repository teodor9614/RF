package usv;

public class MainClass {

	public static void main(String[] args) {
		String[][] learningSet = null;
		try {
			learningSet = FileUtils.readLearningSetFromFile("D:\\3142a\\MT\\Lab5\\data.csv");
			int numberOfPatterns = learningSet.length;
			int numberOfFeatures = learningSet[0].length;
			System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns,
					numberOfFeatures));
			double[][] coords = new double[3][2];
			coords[0][0] = 25.89;
			coords[0][1] = 47.56;
			coords[1][0] = 24;
			coords[1][1] = 45.15;
			coords[2][0] = 25.33;
			coords[2][1] = 45.44;

			double[][] filecoords = new double[learningSet.length][2];
			for (int i = 0; i <= learningSet.length - 1; i++) {

				for (int j = 0; j < 2; j++) {
					filecoords[i][j] = Double.valueOf(learningSet[i][j]);
				}
			}
			DistanceUtils.initmat(3,learningSet.length);

			for (int i = 0; i < 3; i++) {
				for (int j = 0; j < learningSet.length; j++) {
					DistanceUtils.EuclidianDistance(coords[i], filecoords[j], i, j);
					if (j > 13746) {
						break;
					}
				}
			}
			DistanceUtils.sort(learningSet.length);
			DistanceUtils.retmat(learningSet.length);

		} catch (USVInputFileCustomException e) {
			System.out.println(e.getMessage());
		} finally {
			System.out.println("Finished learning set operations");
		}

	}

}

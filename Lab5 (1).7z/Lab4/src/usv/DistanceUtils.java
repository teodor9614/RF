package usv;

import java.text.DecimalFormat;
import java.util.Arrays;

public class DistanceUtils {
	static double sum;
	static double[][] distmat;
	static double[][] sortmat;
	static double[][] min;
	static int count;

	protected static void initmat(int j,int i) {
		distmat = new double[j][i];
		sortmat = new double[j][i];
		min =new double [3][i];
	}

	protected static void EuclidianDistance(double[] a, double[] b, int i, int j) {
		double eucldist = 0;
		sum = 0;
		// System.out.println(Math.sqrt(distmat.length));
		for (int k = 0; k < a.length; k++) {
			eucldist = (a[k] - b[k]) * (a[k] - b[k]);
			sum = sum + eucldist;
		}
		distmat[i][j]=Math.sqrt(sum);
		sortmat[i][j]=Math.sqrt(sum);
		count++;
	}

	protected static void sort(int k) {


		
		for (int i = 0; i <3; i++) {
			
			for (int j = 0; j < k; j++) 
			{
				Arrays.sort(sortmat[i], 0, k);

			}

			
		}

	}

	protected static void retmat(int k) {
		
		
			for (int j = 0; j < k; j++) 
			{
				System.out.println(sortmat[2][j]);
				
			}

		
		
		System.out.println(count);
	}

}
